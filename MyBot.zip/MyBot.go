package main

import (
	"./src"
)

func main() {
	src.Run()
}
